export type StatusCode = {
    [key: string]: number
}

export type ReasonsPhrases = {
    [key: number]: string
}
