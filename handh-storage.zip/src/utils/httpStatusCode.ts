import statusCodes from './statusCode'
import reasonPhrases from './reasonPhrases'

export default  {
    StatusCodes: statusCodes,
    ReasonPharases: reasonPhrases
}